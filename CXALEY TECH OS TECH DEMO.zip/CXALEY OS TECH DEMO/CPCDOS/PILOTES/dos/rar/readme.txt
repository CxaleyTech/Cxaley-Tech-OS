                     Command line 32 bit RAR for DOS
                     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Introduction

   This is DOS version of RAR archiver. It needs 32 bit CPU to work,
so 8086 and 80286 systems are not supported. This RAR/DOS32 provides
only the command line interface. It can process long file names
in Windows DOS box (except Windows NT), but we strongly recommend to
use the native Windows console rar.exe from WinRAR package in Windows.
Native Windows RAR is much more reliable in Windows environment.

   RAR/DOS32 is built by EMX C compiler and it uses RSX DPMI extender.

   DOS SFX module is built by DJ Delorie DJGPP C++ compiler
(www.delorie.com/djgpp) and PMODE/DJ extender written by Thomas Pytel
and Matthias Grimrath.


2. Installation

   This distributive is DOS SFX archive, you need to run it to extract
its contents. Files emx.exe, rsx.exe and emx.dll should be placed to any
directory specified in PATH environment variable. It is also recommended,
though not required, to put rar32.exe to some PATH directory.


3. License

   RAR/DOS32 is shareware, it uses the same registration key format
as WinRAR. Please read License.txt and Order.htm files from WinRAR
distributive for further details.

   Latest versions of RAR/DOS32 and WinRAR are available on
http://www.rarlab.com.
